package org.connection.data.connectivity;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author RocKHaZarD
 */
public class OdbcConnection {

    static private Connection con;
    static public Statement st;
    static public ResultSet rs;
    static private String connectionString;

    public static void getConnection(String... config) {
        try {
            connectionString = "jdbc:mysql://" + config[0] + ":" + config[1] + "/" + config[2];
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(connectionString, config[3], config[4]);
            st = con.createStatement();
            con.setAutoCommit(true);
            System.out.println("Connection Established " + con + " on Statement " + st);
        } catch (SQLException e) {
            Logger.getLogger(OdbcConnection.class.getName()).log(Level.SEVERE, null, e);
        } catch (ClassNotFoundException ce) {
            Logger.getLogger(OdbcConnection.class.getName()).log(Level.SEVERE, null, ce);
        }
    }

    public static Connection getCon() {
        return con;
    }
}
