package org.connection.data.services;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.connection.data.connectivity.OdbcConnection;

/**
 *
 * @author RocKHaZarD
 */
public class DatabaseController {

    public DatabaseController(String host, String portNumber, String databaseName, String databaseUsername, String databasePassword) {
        OdbcConnection.getConnection(host, portNumber, databaseName, databaseUsername, databasePassword);
    }

    public boolean execute(StringBuffer query) {
        try {
            OdbcConnection.st.execute(query.toString());
            return true;
        } catch (SQLException se) {
            Logger.getLogger(DatabaseController.class.getName()).log(Level.SEVERE, null, se);
        }
        return false;
    }

    public ResultSet executeQuery(StringBuffer query) {
        try {
            OdbcConnection.rs = OdbcConnection.st.executeQuery(query.toString());
        } catch (SQLException se) {
            Logger.getLogger(DatabaseController.class.getName()).log(Level.SEVERE, null, se);
        }
        return OdbcConnection.rs;
    }

    public void closeConnection() {
        try {
            OdbcConnection.getCon().close();
        } catch (SQLException se) {
            Logger.getLogger(DatabaseController.class.getName()).log(Level.SEVERE, null, se);
        }
    }

}
